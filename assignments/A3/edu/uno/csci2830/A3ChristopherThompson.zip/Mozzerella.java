package edu.uno.csci2830;

public class Mozzerella extends CheeseTopping {
	@Override
	public String toString() {
		return "Mozzerella";
	}
}
