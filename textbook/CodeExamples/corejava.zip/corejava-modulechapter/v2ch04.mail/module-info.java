@SuppressWarnings("module") module v2ch04.mail {
    requires jakarta.mail;
}
