@SuppressWarnings("module") module v1ch12.automod {
    // requires commons.csv; // Up to 1.9
    requires org.apache.commons.csv;
}
