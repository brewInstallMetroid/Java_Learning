@SuppressWarnings("module") 
module v1ch12.requiremod {
    requires java.desktop;
}
