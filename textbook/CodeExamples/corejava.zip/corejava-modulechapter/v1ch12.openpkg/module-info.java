@SuppressWarnings("module") module v1ch12.openpkg {
    requires com.horstmann.util;
    opens com.horstmann.places to com.horstmann.util;
}
