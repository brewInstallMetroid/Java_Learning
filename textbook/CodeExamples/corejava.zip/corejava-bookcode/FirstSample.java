/**
 * This is the first sample program in Core Java Chapter 3
 */
void main() {
    IO.println("We will not use 'Hello, World!'");
}
