package v2ch13.jnidemo;

class HelloNative {  
    public static native int printf(String str);
}
