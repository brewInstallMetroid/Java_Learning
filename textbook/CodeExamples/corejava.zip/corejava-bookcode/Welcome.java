/**
 * This program displays a greeting for the reader.
 */
void main() {
    String greeting = "Welcome to Core Java!";
    IO.println(greeting);
    IO.println("=".repeat(greeting.length()));
}
