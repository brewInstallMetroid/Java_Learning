@SuppressWarnings("module")
module v1ch12.useservice 
{
   requires com.horstmann.greetsvc;
   uses com.horstmann.greetsvc.GreeterService;
}
